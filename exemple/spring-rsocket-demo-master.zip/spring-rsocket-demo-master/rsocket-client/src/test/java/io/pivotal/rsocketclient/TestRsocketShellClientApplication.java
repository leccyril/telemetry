package io.pivotal.rsocketclient;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

@Disabled
//@SpringBootTest
public class TestRsocketShellClientApplication {

    @Test
    void contextLoads() {
    }
}
